Sample Oxide bot package for the demo.
